-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2022 at 12:45 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stud`
--

-- --------------------------------------------------------

--
-- Table structure for table `anim`
--

CREATE TABLE `anim` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `anim`
--

INSERT INTO `anim` (`id`, `name`, `photo`, `datetime`, `brand_id`) VALUES
(1, 'Sibuyas', '2022-12-14-12-10.png', '2022-12-14 14:16:10', 6),
(2, 'Patani', '2022-12-14-12-50.JPG', '2022-12-14 14:42:50', 6),
(3, 'AMOR F1', '2022-12-15-12-29.png', '2022-12-15 08:49:29', 6),
(4, 'Sagana', '2022-12-15-12-21.png', '2022-12-15 09:42:21', 6);

-- --------------------------------------------------------

--
-- Table structure for table `apat`
--

CREATE TABLE `apat` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apat`
--

INSERT INTO `apat` (`id`, `name`, `photo`, `datetime`, `brand_id`) VALUES
(1, 'Singkamas', '2022-12-14-12-26.jpg', '2022-12-14 14:13:26', 4),
(2, 'Singkamas', '2022-12-14-12-53.PNG', '2022-12-14 14:41:53', 4),
(3, 'Banate King F1', '2022-12-15-12-35.png', '2022-12-15 08:43:35', 4),
(4, 'Patani', '2022-12-15-12-19.jpg', '2022-12-15 09:24:19', 4),
(5, 'Mayumi F1', '2022-12-15-12-30.png', '2022-12-15 09:41:30', 4);

-- --------------------------------------------------------

--
-- Table structure for table `a_history`
--

CREATE TABLE `a_history` (
  `id` int(11) NOT NULL,
  `seed` varchar(255) NOT NULL,
  `tira` int(255) NOT NULL,
  `benta` int(255) NOT NULL,
  `brand_id` int(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `photo` varchar(255) NOT NULL,
  `total` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `a_history`
--

INSERT INTO `a_history` (`id`, `seed`, `tira`, `benta`, `brand_id`, `datetime`, `photo`, `total`) VALUES
(1, 'Kangkong', 10, 47, 1, '2022-12-15 05:44:50', '2022-12-14-12-12.jpg', 500),
(2, 'PIA F1', 10, 47, 1, '2022-12-15 08:51:25', '2022-12-15-12-35.png', 500),
(3, 'PIA F1', 10, 47, 1, '2022-12-15 09:10:15', '2022-12-15-12-35.png', 500),
(4, 'AMOR F1', 10, 47, 1, '2022-12-15 09:43:11', '2022-12-15-12-32.png', 500),
(5, 'AMOR F1', 10, 47, 1, '2022-12-15 09:46:53', '2022-12-15-12-32.png', 500),
(6, 'AMOR F1', 0, 0, 1, '2022-12-15 11:25:40', '2022-12-15-12-32.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `b_history`
--

CREATE TABLE `b_history` (
  `id` int(11) NOT NULL,
  `seed` varchar(255) NOT NULL,
  `tira` int(255) NOT NULL,
  `benta` int(255) NOT NULL,
  `brand_id` int(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `photo` varchar(255) NOT NULL,
  `total` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `b_history`
--

INSERT INTO `b_history` (`id`, `seed`, `tira`, `benta`, `brand_id`, `datetime`, `photo`, `total`) VALUES
(1, 'Patani', 10, 47, 2, '2022-12-15 05:45:24', '2022-12-14-12-43.jpg', 500),
(2, 'Lava F1', 10, 47, 2, '2022-12-15 08:51:58', '2022-12-15-12-53.png', 500),
(3, 'Lava F1', 10, 47, 2, '2022-12-15 09:10:53', '2022-12-15-12-53.png', 500),
(4, 'Banate King F1', 10, 47, 2, '2022-12-15 09:43:33', '2022-12-15-12-54.png', 500);

-- --------------------------------------------------------

--
-- Table structure for table `c_history`
--

CREATE TABLE `c_history` (
  `id` int(11) NOT NULL,
  `seed` varchar(255) NOT NULL,
  `tira` int(255) NOT NULL,
  `benta` int(255) NOT NULL,
  `brand_id` int(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `photo` varchar(255) NOT NULL,
  `total` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `c_history`
--

INSERT INTO `c_history` (`id`, `seed`, `tira`, `benta`, `brand_id`, `datetime`, `photo`, `total`) VALUES
(1, 'Brocoli', 10, 47, 3, '2022-12-15 05:45:39', '2022-12-15-12-58.JPG', 500),
(2, 'Sibuyas', 10, 47, 3, '2022-12-15 08:01:17', '2022-12-15-12-27.jpg', 500),
(3, 'Sagana', 10, 47, 3, '2022-12-15 08:52:22', '2022-12-15-12-09.png', 500),
(4, 'Sagana', 10, 47, 3, '2022-12-15 09:11:22', '2022-12-15-12-09.png', 500),
(5, 'Lava F1', 10, 47, 3, '2022-12-15 09:44:41', '2022-12-15-12-08.png', 500);

-- --------------------------------------------------------

--
-- Table structure for table `dalawa`
--

CREATE TABLE `dalawa` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dalawa`
--

INSERT INTO `dalawa` (`id`, `name`, `photo`, `datetime`, `brand_id`) VALUES
(1, 'Patani', '2022-12-14-12-22.jpg', '2022-12-14 14:06:22', 2),
(2, 'Brocoli', '2022-12-14-12-40.webp', '2022-12-14 14:09:40', 2),
(3, 'Brocoli', '2022-12-14-12-26.jpg', '2022-12-14 14:36:26', 2),
(4, 'Patani', '2022-12-14-12-43.jpg', '2022-12-14 14:39:43', 2),
(5, 'Lava F1', '2022-12-15-12-53.png', '2022-12-15 08:42:53', 2),
(6, 'Banate King F1', '2022-12-15-12-54.png', '2022-12-15 09:40:54', 2);

-- --------------------------------------------------------

--
-- Table structure for table `d_history`
--

CREATE TABLE `d_history` (
  `id` int(11) NOT NULL,
  `seed` varchar(255) NOT NULL,
  `tira` int(255) NOT NULL,
  `benta` int(255) NOT NULL,
  `brand_id` int(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `photo` varchar(255) NOT NULL,
  `total` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `d_history`
--

INSERT INTO `d_history` (`id`, `seed`, `tira`, `benta`, `brand_id`, `datetime`, `photo`, `total`) VALUES
(1, 'Singkamas', 10, 47, 4, '2022-12-15 05:45:56', '2022-12-14-12-53.PNG', 500),
(2, 'Banate King F1', 10, 47, 4, '2022-12-15 08:52:38', '2022-12-15-12-35.png', 500),
(3, 'Banate King F1', 10, 47, 4, '2022-12-15 09:11:39', '2022-12-15-12-35.png', 500),
(4, 'Mayumi F1', 10, 47, 4, '2022-12-15 09:45:00', '2022-12-15-12-30.png', 500);

-- --------------------------------------------------------

--
-- Table structure for table `e_history`
--

CREATE TABLE `e_history` (
  `id` int(11) NOT NULL,
  `seed` varchar(255) NOT NULL,
  `tira` int(255) NOT NULL,
  `benta` int(255) NOT NULL,
  `brand_id` int(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `photo` varchar(255) NOT NULL,
  `total` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `e_history`
--

INSERT INTO `e_history` (`id`, `seed`, `tira`, `benta`, `brand_id`, `datetime`, `photo`, `total`) VALUES
(1, 'Singkamas', 10, 47, 5, '2022-12-15 05:46:14', '2022-12-14-12-25.jpg', 500),
(2, 'Banate King F1', 10, 47, 5, '2022-12-15 08:53:06', '2022-12-15-12-03.png', 500),
(3, 'Banate King F1', 10, 47, 5, '2022-12-15 09:12:00', '2022-12-15-12-03.png', 500),
(4, 'PIA F1', 10, 47, 5, '2022-12-15 09:45:19', '2022-12-15-12-53.png', 500);

-- --------------------------------------------------------

--
-- Table structure for table `f_history`
--

CREATE TABLE `f_history` (
  `id` int(11) NOT NULL,
  `seed` varchar(255) NOT NULL,
  `tira` int(255) NOT NULL,
  `benta` int(255) NOT NULL,
  `brand_id` int(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `photo` varchar(255) NOT NULL,
  `total` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `f_history`
--

INSERT INTO `f_history` (`id`, `seed`, `tira`, `benta`, `brand_id`, `datetime`, `photo`, `total`) VALUES
(1, 'Patani', 10, 47, 6, '2022-12-15 05:46:38', '2022-12-14-12-50.JPG', 500),
(2, 'AMOR F1', 10, 47, 6, '2022-12-15 08:53:22', '2022-12-15-12-29.png', 500),
(3, 'AMOR F1', 10, 47, 6, '2022-12-15 09:12:13', '2022-12-15-12-29.png', 500),
(4, 'Sagana', 10, 47, 6, '2022-12-15 09:45:47', '2022-12-15-12-21.png', 500);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `seed` varchar(255) NOT NULL,
  `tira` int(255) NOT NULL,
  `benta` int(255) NOT NULL,
  `brand_id` int(50) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `photo` varchar(255) NOT NULL,
  `total` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `seed`, `tira`, `benta`, `brand_id`, `datetime`, `photo`, `total`) VALUES
(38, 'AMOR F1', 10, 47, 1, '2022-12-15 09:43:11', '2022-12-15-12-32.png', 500),
(39, 'Banate King F1', 10, 47, 2, '2022-12-15 09:43:33', '2022-12-15-12-54.png', 500),
(40, 'Lava F1', 10, 47, 3, '2022-12-15 09:44:41', '2022-12-15-12-08.png', 500),
(41, 'Mayumi F1', 10, 47, 4, '2022-12-15 09:45:00', '2022-12-15-12-30.png', 500),
(42, 'PIA F1', 10, 47, 5, '2022-12-15 09:45:19', '2022-12-15-12-53.png', 500),
(43, 'Sagana', 10, 47, 6, '2022-12-15 09:45:47', '2022-12-15-12-21.png', 500),
(44, 'AMOR F1', 10, 47, 1, '2022-12-15 09:46:53', '2022-12-15-12-32.png', 500),
(45, 'AMOR F1', 0, 0, 1, '2022-12-15 11:25:40', '2022-12-15-12-32.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `isa`
--

CREATE TABLE `isa` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `isa`
--

INSERT INTO `isa` (`id`, `name`, `photo`, `datetime`, `brand_id`) VALUES
(1, 'Kalabasa', 'png', '2022-12-14 06:41:08', 0),
(2, 'Talong', 'jpg', '2022-12-14 06:42:27', 0),
(3, 'Talong', '2022-12-14-12-22.jpg', '2022-12-14 06:44:22', 0),
(4, 'Patani', '2022-12-14-12-07.png', '2022-12-14 07:37:07', 1),
(5, 'Labanosnos', '2022-12-14-12-32.png', '2022-12-14 07:45:32', 4),
(6, 'Sibuyas', '2022-12-14-12-21.jpg', '2022-12-14 07:46:21', 1),
(7, 'Brocoli', '2022-12-14-12-43.jpg', '2022-12-14 13:09:43', 1),
(8, 'Labanosnos', '2022-12-14-12-21.jpg', '2022-12-14 13:23:21', 2),
(9, 'Kamatis', '2022-12-14-12-39.jpg', '2022-12-14 13:24:39', 3),
(10, 'Patani', '2022-12-14-12-09.PNG', '2022-12-14 13:25:09', 4),
(11, 'Singkamas', '2022-12-14-12-53.jpg', '2022-12-14 13:27:53', 5),
(12, 'Brocoli', '2022-12-14-12-17.webp', '2022-12-14 13:28:17', 6),
(13, 'Sibuyas', '2022-12-14-12-20.PNG', '2022-12-14 14:32:20', 1),
(14, 'Kangkong', '2022-12-14-12-12.jpg', '2022-12-14 14:33:12', 1),
(15, 'PIA F1', '2022-12-15-12-35.png', '2022-12-15 08:42:35', 1),
(16, 'AMOR F1', '2022-12-15-12-32.png', '2022-12-15 09:40:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `lahat`
--

CREATE TABLE `lahat` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lahat`
--

INSERT INTO `lahat` (`id`, `name`, `photo`, `datetime`, `brand_id`) VALUES
(2, 'Kangkong', '2022-12-14-12-12.jpg', '2022-12-14 14:33:12', 1),
(3, 'Brocoli', '2022-12-14-12-26.jpg', '2022-12-14 14:36:26', 1),
(4, 'Patani', '2022-12-14-12-43.jpg', '2022-12-14 14:39:43', 2),
(5, 'Labanosnos', '2022-12-14-12-35.webp', '2022-12-14 14:41:35', 3),
(8, 'Mustasa', '2022-12-14-12-50.JPG', '2022-12-14 14:42:50', 6),
(9, 'Brocoli', '2022-12-15-12-58.JPG', '2022-12-15 02:34:58', 3),
(18, 'AMOR F1', '2022-12-15-12-32.png', '2022-12-15 09:40:32', 1),
(19, 'Banate King F1', '2022-12-15-12-54.png', '2022-12-15 09:40:54', 2),
(20, 'Lava F1', '2022-12-15-12-08.png', '2022-12-15 09:41:08', 3),
(21, 'Mayumi F1', '2022-12-15-12-30.png', '2022-12-15 09:41:30', 4),
(22, 'PIA F1', '2022-12-15-12-53.png', '2022-12-15 09:41:53', 5),
(23, 'Sagana', '2022-12-15-12-21.png', '2022-12-15 09:42:21', 6);

-- --------------------------------------------------------

--
-- Table structure for table `lima`
--

CREATE TABLE `lima` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lima`
--

INSERT INTO `lima` (`id`, `name`, `photo`, `datetime`, `brand_id`) VALUES
(1, 'Labanosnos', '2022-12-14-12-50.jpg', '2022-12-14 14:13:50', 5),
(2, 'Singkamas', '2022-12-14-12-25.jpg', '2022-12-14 14:42:25', 5),
(3, 'Banate King F1', '2022-12-15-12-03.png', '2022-12-15 08:49:03', 5),
(4, 'PIA F1', '2022-12-15-12-53.png', '2022-12-15 09:41:53', 5);

-- --------------------------------------------------------

--
-- Table structure for table `overall`
--

CREATE TABLE `overall` (
  `product_id` int(11) NOT NULL,
  `seed` varchar(255) NOT NULL,
  `tira` varchar(255) NOT NULL,
  `benta` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(11) NOT NULL,
  `total` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `overall`
--

INSERT INTO `overall` (`product_id`, `seed`, `tira`, `benta`, `created_date`, `brand_id`, `total`) VALUES
(1, 'Kalabasa', '1', '22', '2022-12-14 11:05:44', 1, 466);

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `id` int(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  `roll` int(6) NOT NULL,
  `class` varchar(3) NOT NULL,
  `city` varchar(15) NOT NULL,
  `pcontact` varchar(11) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`id`, `name`, `roll`, `class`, `city`, `pcontact`, `photo`, `datetime`) VALUES
(48, 'Maecah', 443357, '2nd', 'Palhi', '01814270595', '4433572022-12-13-12-44.jpg', '2022-12-13 11:55:44'),
(64, 'Maecah Ganda', 446688, '4th', 'Bayanan', '01814270111', '4466882022-12-14-12-08.png', '2022-12-14 01:48:08'),
(65, 'Rasta Mann', 553344, '3rd', 'calapan city, o', '01814270498', '5533442022-12-14-12-52.png', '2022-12-14 01:49:52'),
(66, 'Alea Garong', 221155, '3rd', 'Palhi', '01814270500', '2211552022-12-14-12-06.png', '2022-12-14 05:10:06');

-- --------------------------------------------------------

--
-- Table structure for table `tatlo`
--

CREATE TABLE `tatlo` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tatlo`
--

INSERT INTO `tatlo` (`id`, `name`, `photo`, `datetime`, `brand_id`) VALUES
(1, 'Kamatis', '2022-12-14-12-15.PNG', '2022-12-14 14:12:15', 3),
(3, 'Brocoli', '2022-12-15-12-58.JPG', '2022-12-15 02:34:58', 3),
(4, 'Sibuyas', '2022-12-15-12-27.jpg', '2022-12-15 07:59:27', 3),
(5, 'Sagana', '2022-12-15-12-09.png', '2022-12-15 08:43:09', 3),
(6, 'Lava F1', '2022-12-15-12-08.png', '2022-12-15 09:41:08', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `status` varchar(12) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `photo`, `status`, `datetime`) VALUES
(23, 'Martin Caringal', 'rencecaringal@gmail.com', 'rence_caringal', '1f82ea75c5cc526729e2d581aeb3aeccfef4407e', 'rence_caringal.JPG', 'active', '2022-12-15 10:01:46'),
(24, 'Martin Caringal', 'lawrencecaringal5@gmail.com', 'lawrencecaringal5', '1f82ea75c5cc526729e2d581aeb3aeccfef4407e', 'lawrencecaringal5.jpg', 'active', '2022-12-15 10:04:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anim`
--
ALTER TABLE `anim`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apat`
--
ALTER TABLE `apat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `a_history`
--
ALTER TABLE `a_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `b_history`
--
ALTER TABLE `b_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_history`
--
ALTER TABLE `c_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dalawa`
--
ALTER TABLE `dalawa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `d_history`
--
ALTER TABLE `d_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_history`
--
ALTER TABLE `e_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `f_history`
--
ALTER TABLE `f_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `isa`
--
ALTER TABLE `isa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lahat`
--
ALTER TABLE `lahat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lima`
--
ALTER TABLE `lima`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `overall`
--
ALTER TABLE `overall`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roll` (`roll`);

--
-- Indexes for table `tatlo`
--
ALTER TABLE `tatlo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anim`
--
ALTER TABLE `anim`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `apat`
--
ALTER TABLE `apat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `a_history`
--
ALTER TABLE `a_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `b_history`
--
ALTER TABLE `b_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `c_history`
--
ALTER TABLE `c_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dalawa`
--
ALTER TABLE `dalawa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `d_history`
--
ALTER TABLE `d_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `e_history`
--
ALTER TABLE `e_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `f_history`
--
ALTER TABLE `f_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `isa`
--
ALTER TABLE `isa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `lahat`
--
ALTER TABLE `lahat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `lima`
--
ALTER TABLE `lima`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `overall`
--
ALTER TABLE `overall`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_info`
--
ALTER TABLE `student_info`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `tatlo`
--
ALTER TABLE `tatlo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
