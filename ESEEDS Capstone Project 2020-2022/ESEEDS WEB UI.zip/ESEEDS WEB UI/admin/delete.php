
<?php 
//session_start();
if (isset($_SESSION['user_login'])) {
	$id = base64_decode($_GET['id']);
	$photo = base64_decode($_GET['photo']);
	if(mysqli_query($db_con,"DELETE FROM `lahat` WHERE `id` = '$id'")){
		unlink('images/'.$photo);
		// header('Location: index.php?page=all-student&delete=success');
	}else{
		// header('Location: index.php?page=all-student&delete=error');
	}
}else{
	// header('Location: login.php');
 }

// $yes = '1';
// if($yes = 1){
//  header("Location: all-student.php");
//  exit(0);
// }
?>
<script>
	window.location.href='index.php?page=all-student';
</script>