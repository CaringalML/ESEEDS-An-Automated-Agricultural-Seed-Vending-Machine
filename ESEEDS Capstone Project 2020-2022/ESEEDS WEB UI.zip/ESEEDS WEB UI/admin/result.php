<?php
require 'db_con.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>ESEEDS PRICES</title>
</head>

<body>
 <?php

$response = array();
$posts = array();

  $sql = "SELECT * FROM prices";
  $result = $db_con ->query($sql);
  while($row = $result->fetch_assoc()) {
    
   $index = $row['index'];
   $value = $row['value'];
   $posts[] = array('index'=>$index, 'value'=>$value);
  }

  $response['posts'] = $posts;

 $fp = fopen('results.json', 'w');
 fwrite($fp, json_encode($response));
 fclose($fp);


  ?>
</body>

</html>