<?php
require 'db_con.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>ESEEDS PRICES</title>
</head>

<body>
 <?php

$response = array();
$posts = array();

  $sql = "SELECT * FROM prices LIMIT 1";
  $result = $db_con ->query($sql);

  $dbdata = [];

  while($row = $result->fetch_assoc()) {
    
   $dbdata[] = $row;
  }

//Print array in JSON format
echo json_encode($dbdata);


  ?>
</body>

</html>