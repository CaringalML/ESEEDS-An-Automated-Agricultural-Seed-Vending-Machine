<?php

require 'db_con.php';

$tira = $_GET['tirasix'];
$benta = $_GET['bentasix'];
$total = $_GET['lahat'];
$brand_id='6';

// $tira ='10';
// $benta ='47';
// $brand_id='6';
// $total ='500';

//$sql = "UPDATE con1 SET isa='$isa',salesone='$salesone'  WHERE id=1";

$sql= "SELECT * FROM anim WHERE id = (SELECT MAX(id) FROM anim)";
$result = $db_con ->query($sql);
while($row = $result->fetch_assoc()) {

$one = $row['name'];
$photo = $row['photo'];
//echo "$one";

}

$sql = "INSERT INTO history (seed,tira,benta,brand_id,photo,total)
VALUES('".$one."','".$tira."','".$benta."','".$brand_id."','".$photo."','".$total."')";

if ($db_con ->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $db_con ->error;
  }



  ///////////////////////////////////////////////////////////////////////////////
  $sql = "INSERT INTO f_history (seed,tira,benta,brand_id,photo,total)
VALUES('".$one."','".$tira."','".$benta."','".$brand_id."','".$photo."','".$total."')";

if ($db_con ->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $db_con ->error;
  }


//   //for updating the remaining Item
//   $sql = "UPDATE students SET tira='$tira'  WHERE id=6";

//   if ($db->query($sql) === TRUE) {
//     echo "Update record successfully";
//     echo "<br>";
//   } else {
//     echo "Error: " . $sql . "<br>" . $db->error;
//   }


//   //for updating the Item One sales
//   $sql = "UPDATE students SET benta='$benta'  WHERE id=6";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }

// //for updating the total sales
// $sql = "UPDATE students SET total='$total'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }

// $sql = "UPDATE lahat SET salesone='$salesone'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }

// //////////////////////////////////////////////////////////////////////////////////////

// $sql = "UPDATE lahat SET dalawa='$dalawa'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }


// $sql = "UPDATE lahat SET salestwo='$salestwo'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }

// /////////////////////////////////////////////////////////////////////////////////////

// $sql = "UPDATE lahat SET tatlo='$tatlo'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }


// $sql = "UPDATE lahat SET salesthree='$salesthree'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }

// //////////////////////////////////////////////////////////////////////////////////////

// $sql = "UPDATE lahat SET apat='$apat'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }


// $sql = "UPDATE lahat SET salesfour='$salesfour'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }

// ///////////////////////////////////////////////////////////////////////////////////////

// $sql = "UPDATE lahat SET lima='$lima'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }


// $sql = "UPDATE lahat SET salesfive='$salesfive'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }

// ///////////////////////////////////////////////////////////////////////////////////////////

// $sql = "UPDATE lahat SET anim='$anim'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }


// $sql = "UPDATE lahat SET salessix='$salessix'  WHERE id=1";

// if ($db->query($sql) === TRUE) {
//   echo "Update record successfully";
//   echo "<br>";
// } else {
//   echo "Error: " . $sql . "<br>" . $db->error;
// }

// ///////////////////////////////////////////////////////////////////////////////////////////////

// $sql = "UPDATE lahat SET total='$total' WHERE id=1";

// if ($db->query($sql) === TRUE) {
//     echo "Update record successfully";
//     echo "<br>";
//   } else {
//     echo "Error: " . $sql . "<br>" . $db->error;
//   }

//   //////////////////////////////////////////////////////////////////////////////////////////////
  
// //   $sql = "INSERT INTO lahat (isa,dalawa,tatlo,apat,lima,anim,salesone,salestwo,salesthree,salesfour,salesfive,salessix,created_date,total)
// // VALUES('".$isa."','".$dalawa."','".$tatlo."','".$apat."','".$lima."','".$anim."','".$salesone."','".$salestwo."','".$salesthree."','".$salesfour."','".$salesfive."','".$salessix."', '".date("Y-m-d H:i:s")."','".$total."')";


// // if ($db->query($sql) === TRUE) {
// //   echo "New record created successfully";
// //   echo "<br>";
// // } else {
// //   echo "Error: " . $sql . "<br>" . $db->error;
// // }

// // $sql = "INSERT INTO totals (total,created_date)
// // VALUES('".$total."','".date("Y-m-d H:i:s")."')";

// // if ($db->query($sql) === TRUE) {
// //     echo "New record created successfully";
// //   } else {
// //     echo "Error: " . $sql . "<br>" . $db->error;
// //   }

$db_con->close();

?>