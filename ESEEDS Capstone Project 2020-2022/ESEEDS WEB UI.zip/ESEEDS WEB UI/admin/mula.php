<?php require_once 'db_con.php';
session_start();
if (!isset($_SESSION['user_login'])) {
  header('Location: login.php');
}
?>
<!doctype html>
<html lang="en">
  <head>


  <meta charset="UTF-8">
    <!-- <title> Responsive Sidebar Menu  | CodingLab </title> -->
    <link rel="stylesheet" href="style.css">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/solid.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="../css/style.css">

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../js/jquery-3.5.1.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>
    <script src="../js/dataTables.bootstrap4.min.js"></script>
    <script src="../js/fontawesome.min.js"></script>
    <script src="../js/script.js"></script>
    <title>Admin Deshboard</title>
  </head>
  <body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php"><i class="fas fa-chart-line fa-3x"></i></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="navbar-collapse collapse justify-content-end" id="navbarSupportedContent">
    <?php $showuser = $_SESSION['user_login']; $haha = mysqli_query($db_con,"SELECT * FROM `users` WHERE `username`='$showuser';"); $showrow=mysqli_fetch_array($haha); ?>
    <ul class="nav navbar-nav ">
      <li class="nav-item"><a class="nav-link" href="index.php?page=user-profile"><i class="fa fa-user"></i> Welcome <?php echo $showrow['name']; ?>!</a></li>
      <li class="nav-item"><a class="nav-link" href="index.php?page=add-student"><i class="fa fa-user-plus"></i> Add Product</a></li>
      <li class="nav-item"><a class="nav-link" href="index.php?page=user-profile"><i class="fa fa-user"></i> Profile</a></li>
      <li class="nav-item"><a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
    </ul>
  </div>
</nav>
<br>
    <!-- <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="list-group">
              <a href="index.php?page=dashboard" class="list-group-item list-group-item-action active">
               <i class="fas fa-tachometer-alt"></i> Dashboard
              </a>
              <a href="index.php?page=add-student" class="list-group-item list-group-item-action"><i class="fa fa-user-plus"></i> Add Student</a>
              <a href="index.php?page=all-student" class="list-group-item list-group-item-action"><i class="fa fa-users"></i> All Students</a>
              <a href="index.php?page=all-users" class="list-group-item list-group-item-action"><i class="fa fa-users"></i> All Users</a>
              <a href="index.php?page=user-profile" class="list-group-item list-group-item-action"><i class="fa fa-user"></i> User Profile</a>
            </div>
          </div> -->

<!-- <br> -->



          <div class="sidebar">
    <div class="logo-details">
    <i class='bx bxl-spring-boot'></i>
        <div class="logo_name">ESEEDS</div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
          <i class='bx bx-search' ></i>
         <input type="text" placeholder="Search...">
         <span class="tooltip">Search</span>
      </li>
      <li>
        <a href="index.php?page=dashboard">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <li>
       <a href="index.php?page=all-users">
         <i class='bx bx-user' ></i>
         <span class="links_name">Admin Users</span>
       </a>
       <span class="tooltip">Admin Users</span>
     </li>
     <li>
       <!-- <a href="#">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Messages</span>
       </a>
       <span class="tooltip">Messages</span>
     </li>
     <li>
       <a href="#">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Analytics</span>
       </a>
       <span class="tooltip">Analytics</span>
     </li>
     <li>
       <a href="#">
         <i class='bx bx-folder' ></i>
         <span class="links_name">File Manager</span>
       </a>
       <span class="tooltip">Files</span>
     </li>
     <li>
       <a href="#">
         <i class='bx bx-cart-alt' ></i>
         <span class="links_name">Order</span>
       </a>
       <span class="tooltip">Order</span>
     </li>
     <li>
       <a href="#">
         <i class='bx bx-heart' ></i>
         <span class="links_name">Saved</span>
       </a>
       <span class="tooltip">Saved</span>
     </li>
     <li> -->

     <li>
       <a href="index.php?page=all-student">
       <i class='bx bx-calendar-edit'></i>
         <span class="links_name">Manage Products</span>
       </a>
       <span class="tooltip">Manage Products</span>
     </li>
     <li>

     <li>
       <a href="index.php?page=add-student">
       <i class='bx bx-plus'></i>
         <span class="links_name">Add Products</span>
       </a>
       <span class="tooltip">Add Products</span>
     </li>
     <li>
      

     <li>
     <li>
       <a href="index.php?page=user-profile">
       <i class='bx bx-user-circle'></i>
         <span class="links_name">Admin Profile</span>
       </a>
       <span class="tooltip">Admin Profile</span>
     </li>
     <li>


<!-- 
<li>
     <li>
       <a href="logout.php">
       <i class='bx bx-log-out'></i>
         <span class="links_name">Logout</span>
       </a>
       <span class="tooltip">Logout</span>
     </li>
     <li> -->




     

      <!-- <li>
     <li>
       <a href="simula.php?page=user-profile">
       <i class='bx bx-user-circle'></i>
         <span class="links_name">Admin Profile</span>
       </a>
       <span class="tooltip">Admin Profile</span>
     </li>
     <li> -->

       <!-- <a href="#">
         <i class='bx bx-cog' ></i>
         <span class="links_name">Setting</span>
       </a>
       <span class="tooltip">Setting</span>
     </li> -->
     
<?php 
  //include 'profile_pa.php';

 ?>
     <li class="profile">
         <div class="profile-details">
         <img src="Caringal_Martin_Lawrence_M.jpg" alt="profileImg">
           <div class="name_job">
             <div class="name">Martin Caringal</div>
             <div class="job">Software Developer</div>
           </div>
         </div>
         
         <a href="logout.php">
          
         <i class='bx bx-log-out' id="log_out" ></i>
        </a>
         <!-- <a href="logout.php"> -->
     </li>
    </ul>
  </div>
  <section class="home-section">
      <!-- <div class="text">Dashboard</div> -->

      <div class="col-md-9">
             <div class="content">
                 <?php 
                   if (isset($_GET['page'])) {
                    $page = $_GET['page'].'.php';
                    }else{
                      $page = 'dashboard.php';
                    }

                    if (file_exists($page)) {
                      require_once $page;
                    }else{
                      require_once '404.php';
                    }
                  ?>
             </div>
        </div>
        </div>  
    </div>
    
    <div class="clearfix"></div>
    <footer class="text-center text-white" style="background-color: #152238;">
      <div class="container">
      <!-- <p>Copyright &copy; 2021 to <?php //echo date('Y') ?></p> -->


        <!-- Grid container -->
  <div class="container pt-4">
    <!-- Section: Social media -->
    <section class="mb-4">
      <!-- Facebook -->
      <a class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://www.facebook.com/martinlawrence.caringal/" role="button" data-mdb-ripple-color="dark"><i class='bx bxl-facebook-circle'></i></a>

      <!-- Twitter -->
      <a
        class="btn btn-link btn-floating btn-lg text-dark m-1"
        href="https://twitter.com/RenceCaringal"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class='bx bxl-twitter'></i></a>

      
      <!-- Instagram -->
      <a
        class="btn btn-link btn-floating btn-lg text-dark m-1"
        href="https://www.instagram.com/rence_caringal/"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class='bx bxl-instagram-alt' ></i></a>

      <!-- Linkedin -->
      <a
        class="btn btn-link btn-floating btn-lg text-dark m-1"
        href="https://www.linkedin.com/in/martin-lawrence-caringal-6a1548247/?fbclid=IwAR2sXXX1I_Oh2C4R5b5kXU5dkl6zbFb97GdcjUGYvzTgMiSkufvZlfTeOE4"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class='bx bxl-linkedin'></i></a>
      <!-- Github -->
      <a
        class="btn btn-link btn-floating btn-lg text-dark m-1"
        href="https://github.com/CaringalML"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class='bx bxl-github'></i></a>
    </section>
    <!-- Section: Social media -->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="container" style="background-color: #192841;">
  <p>Copyright &copy; 2021 to <?php echo date('Y') ?></p>
  </div>
  <!-- Copyright -->

      </div>
    </footer>

<style>

/* .footer { position: fixed; top: 90%; left: 0; right: 0; bottom: 0;
      background: #ffffff; border: solid black; border-width: 2px 0 0 0; }  */

      .boy { position: fixed; top: 90%; left: 0; right: 0; bottom: 0;
      background: #ffffff; } 
</style>


    <script type="text/javascript">
      jQuery('.toast').toast('show');
    </script>


  </section>

  <script src="script.js"></script>




          <!-- <div class="col-md-9">
             <div class="content">
                 <?php 
                  //  if (isset($_GET['page'])) {
                  //   $page = $_GET['page'].'.php';
                  //   }else{
                  //     $page = 'dashboard.php';
                  //   }

                  //   if (file_exists($page)) {
                  //     require_once $page;
                  //   }else{
                  //     require_once '404.php';
                  //   }
                  ?>
             </div>
        </div>
        </div>  
    </div>
    <div class="clearfix"></div>
    <footer>
      <div class="container">
      <p>Copyright &copy; 2016 to <?php //echo date('Y') ?></p>
      </div>
    </footer>
    <script type="text/javascript">
      jQuery('.toast').toast('show');
    </script> -->
  </body>
</html>