<?php
require 'db_con.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>ESEEDS PRICES</title>
</head>

<body>
 <?php

  $sql = "SELECT * FROM prices";

  $result = $db_con ->query($sql);

  $json_array = array();

  while($row = $result->fetch_assoc()) {

    $json_array[] = $row;
  }

  echo json_encode($json_array);

  /*
echo '<pre>';
print_r($json_array);
echo '</pre>'; */


  ?>
</body>

</html>