<?php 
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBNAME', 'stud');


$db_con = mysqli_connect(DBHOST, DBUSER, '', DBNAME);
