<?php

require 'db_con.php';

$sql = "SELECT * FROM prices WHERE id=1";
$result = $db_con ->query($sql);
while($row = $result->fetch_assoc()) {

$index = $row['index'];
$value = $row['value'];

echo "$index";
echo "$value";
echo '<br>';

}

$sql = "SELECT * FROM prices WHERE id=2";
$result = $db_con ->query($sql);
while($row = $result->fetch_assoc()) {

$index = $row['index'];
$value = $row['value'];

echo "$index";
echo "$value";
echo '<br>';

}

$sql = "SELECT * FROM prices WHERE id=3";
$result = $db_con ->query($sql);
while($row = $result->fetch_assoc()) {

$index = $row['index'];
$value = $row['value'];

echo "$index";
echo "$value";
echo '<br>';

}

$sql = "SELECT * FROM prices WHERE id=4";
$result = $db_con ->query($sql);
while($row = $result->fetch_assoc()) {

$index = $row['index'];
$value = $row['value'];

echo "$index";
echo "$value";
echo '<br>';

}


$sql = "SELECT * FROM prices WHERE id=5";
$result = $db_con ->query($sql);
while($row = $result->fetch_assoc()) {

$index = $row['index'];
$value = $row['value'];

echo "$index";
echo "$value";
echo '<br>';

}


$sql = "SELECT * FROM prices WHERE id=6";
$result = $db_con ->query($sql);
while($row = $result->fetch_assoc()) {

$index = $row['index'];
$value = $row['value'];

echo "$index";
echo "$value";
echo '<br>';

}


?>